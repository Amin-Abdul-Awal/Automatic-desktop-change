import schedule
import time
import ctypes
from PythonScripts.MessageSender import *
from win10toast import ToastNotifier

img = createSalahTimesAndDateImage("Uk","london","C:/users/amina/Desktop/PrayerTimeTableApp/salah times.png")


def changeBackground(filepath):
    print("generating image")
    createSalahTimesAndDateImage("Uk", "London", filepath)
    print("generated image")
    time.sleep(10)
    print("setting new desktop bg")
    ctypes.windll.user32.SystemParametersInfoW(20,0,filepath,0)
    print("new desktop bg set")
    toaster=ToastNotifier()
    toaster.show_toast("Salah time App","Background has changed")




schedule.every().day.at("20:54").do(lambda : changeBackground("C:/users/amina/Desktop/PrayerTimeTableApp/salah times.png"))




while True:
    print("pending...")
    schedule.run_pending()
    time.sleep(10)


