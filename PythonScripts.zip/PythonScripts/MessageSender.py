from PIL import Image, ImageDraw, ImageFont
from PythonScripts.Backend import *



def createSalahTimesAndDateImage(Country, city,filename):
    img = Image.new('RGB', (1000, 700), color=(30, 30, 30))
    SalahFont = ImageFont.truetype('C:\WINDOWS\FONTS\ARIAL.ttf', 30)
    DateFont=ImageFont.truetype('C:\WINDOWS\FONTS\ARIAL.ttf',40)
    SalahTimesImage = ImageDraw.Draw(img)

    salahList = getSalahTimes(Country,city)
    gregorianDate=getDate(Country,city,"gregorian","en")
    hijriDate=getDate(Country,city,"hijri","en")

    i=0
    for j in range(len(salahList)):
        SalahTimesImage.text((450,200+j*40), salahList[j], font=SalahFont, fill=(255, 255, 255))
        i+=1

    SalahTimesImage.text((300,100),hijriDate,font=DateFont,fill=(255,255,255))
    SalahTimesImage.text((320,100+50),gregorianDate,font=DateFont,fill=(255,255,255))
    img.save(filename)